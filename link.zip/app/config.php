<?php
return [
    "db" => [
        "servername" => "localhost",
        "dbname" => "link",
        "username" => "root",
        "password" => ""
    ]
];